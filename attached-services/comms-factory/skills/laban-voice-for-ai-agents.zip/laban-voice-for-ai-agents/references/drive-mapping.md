# Drive mapping reference

Mirodan's four Drives: **Doing · Spell · Passion · Vision.**

Drives are how a character is generated — the energy axes the character lives on. They are determined by the combination of (Inner Attitude + Stress + Aspect). Different placements activate different Drives, which means different vocabulary families are on-spec or off-spec.

## Why Drives matter for voice

Each Drive has a vocabulary footprint:

- **Doing** — concrete, finished actions. "Shipped." "Built." "Live." Past-perfect and present-tense.
- **Spell** — timeless craft, patience, restraint. "Has been building." "Section by section." No urgency. Future-tense lifts but isn't time-pressed.
- **Passion** — time-pressed, emotional, urgency theatre. "Now or never." "Don't miss." "Today only." FOMO. Hype.
- **Vision** — future-pulled, what-will-be, agent-future tense. "A few months from now." "In a couple of years."

**Drive-lock is the off-spec filter.** If a character carries Spell + Vision but NOT Passion, then Passion-vocabulary is off-spec. The validator's `rejectOffSpecDrive` regex enforces this.

## Drive sub-diagrams (Mirodan §3)

Each baseline (Stable, Adream, Near) has multiple Drive sub-diagrams determined by stress and aspect. The diagram is what tells you which Drives are active.

### Stable

| Stress | Aspect | Diagram | Primary axis | Sub-axis | Example characters |
|--------|--------|---------|--------------|----------|---------------------|
| Time | Enclosing | A | Doing / Spell | Doing-Passion | Creon, Hawthorne |
| Time | Penetrating | (varies) | Doing / Spell | Doing-Passion | The investigator characters |
| Flow | Enclosing | (varies) | Spell / Doing | Spell-Vision | softer Stable variants |
| Flow | Penetrating | **D** | **Spell / Doing** | **Spell-Vision** | **the Duke (Measure for Measure), Werle (Wild Duck)** |

**Stable + Flow-stressed + Penetrating (Diagram D) is special** — it's the only baseline placement that carries Spell + Vision *with no Passion at all*. Used by Infinex.

### Adream

| Stress | Aspect | Diagram | Primary axis | Sub-axis | Example characters |
|--------|--------|---------|--------------|----------|---------------------|
| Space | Enclosing | A | Spell / Passion | Spell-Doing | Claudius |
| Space | Radiating | B | Spell / Passion | Spell-Vision | Hamlet, Hedda Gabler, Miss Julie |
| Time | Enclosing | C | Passion / Spell | Passion-Doing | Gertrude, Stanley, Lear, Jean |
| Time | Radiating | D | Passion / Spell | Passion-Vision | Ophelia, Lovborg, Blanche |

**Note:** Adream Space-stressed Radiating (B) carries Spell + Vision *but also mixes in Passion*. If the operator wants "vision-pulled, no urgency," this placement is wrong — Stable + Flow Diagram D is right.

### Near

Always Doing + Passion. Inner = Weight + Time means Time-axis is always part of the inner make-up — Passion is structurally present. Near characters can never be purely Spell-driven.

## Status grammar (Mirodan §4.4, p. 458)

> "The more developed (more mature or higher in status) a character is, the more likely it is that it will have a Space-stress. Less developed Near characters are Flow-stressed, while Adream characters which are lower either in intelligence or in social position are Time-stressed."

| Stress | Reads as |
|--------|----------|
| Time | adolescent / lower status / immature |
| Space | mature / higher status / sophisticated |
| Flow | emotional / sociable |
| Weight | (only on outer Mobile/Remote/Awake projections) |

**For brand voice:** if the operator wants the brand to read mature/grown-up, Time-stress is wrong (it reads adolescent). Space or Flow.

## Drive → vocabulary mapping (operational)

### Doing-on-spec phrases
- "Shipped X."
- "Live today."
- "Built in [duration]."
- "We've been doing X for [years]."
- Past-perfect + present-tense.

### Spell-on-spec phrases
- "We've been building this for years."
- "Section by section."
- "Patient."
- "The craft of [X]."
- "Has always been about [Y]."
- Long-arc, timeless framing.

### Passion-on-spec phrases (and OFF-SPEC for Spell-only characters)
- "Act now."
- "Today only."
- "Don't miss."
- "Last chance."
- "Hurry."
- "Buckle up."
- "Let's go."
- "Wagmi."
- "FOMO."
- Anything that activates urgency-as-virtue.

### Vision-on-spec phrases
- "A few months from now..."
- "In a couple of years..."
- "What this lets your agent do..."
- "The world this opens..."
- "Stop having to [current pain] — soon."
- Future-tense as the dominant grammatical move.

## Practical: how to write the off-spec regex

Once Drive is locked, identify off-spec drive(s) and build a regex per off-spec drive's vocabulary family.

For Infinex (Spell + Vision, no Passion):

```typescript
const OFF_SPEC_REGEXES = [
  {
    name: "time-pressure",
    re: /\b(act\s+(?:now|fast)|hurry|last\s+chance|don't\s+miss|limited\s+time|today\s+only|right\s+now)\b/i,
    reason: "time-pressure phrase activates Passion drive — off-spec for Spell+Vision",
  },
  {
    name: "fomo-urgency",
    re: /\b(FOMO|missing\s+out|don't\s+sleep\s+on)\b/i,
    reason: "FOMO/urgency markers — off-spec for Spell-driven character",
  },
  {
    name: "hype-theatre",
    re: /\b(buckle\s+up|let's\s+go!?|wagmi|gm\s+gm|massive\s+update|huge\s+news)\b/i,
    reason: "hype-theatre vocab — Passion-drive activator",
  },
];
```

Iterate this list as the operator encounters slop the regex didn't catch.

## Cross-references

- `references/mirodan-master.md` §3 for full placement detail per Inner Attitude
- `references/working-actions.md` for the 8 motors each tempo fires
- `references/nigel-pattern.md` for how the generator/validator consumes the Drive lock
