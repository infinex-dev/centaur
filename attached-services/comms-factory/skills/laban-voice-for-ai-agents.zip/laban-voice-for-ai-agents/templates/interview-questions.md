# Interview questions — 3-move workflow

Use these scripts when running an operator through the voice-spec workflow. The questions are ordered so each answer constrains the next.

## Move 1 — Placement (Inner Attitude + Stress + Drive)

### Q1.1 — The character behind the brand

**Ask:** "When a reader encounters this brand, who are they talking to? Give me an image — not a list of adjectives. Best friend? Accountant? Taxman? Mentor? Old curmudgeon at the bar? The architect of a bridge? The watchmaker who's been making the same watch for thirty years?"

**Why:** This anchors the rest. If the operator gives adjectives ("warm, confident, but not arrogant"), push back: "what KIND of person is warm-confident-not-arrogant?" Force the concrete image.

### Q1.2 — Shipper / Visionary / Down-to-earth

**Ask:** "Does this character SHIP things — bridges built, products delivered, infrastructure done? Or are they VISION-pulled toward a future their grounding doesn't quite reach? Or are they DOWN-TO-EARTH — common sense, a-spade's-a-spade, sensory?"

**Map:**
- Ships things → **Stable** baseline (intelligent ruler, decisions taken)
- Vision-pulled-but-torn → **Adream** baseline (the lover, doubly unaware, vision exceeds grounding)
- Down-to-earth-sensory → **Near** baseline (relating, common sense)

### Q1.3 — Time / Space / Flow stress

**Ask:** "When the character is pressed, where does the pressure come from?"

- Pressure from TIME (urgency, deadlines, must-act-now energy) → **Time-stressed**
- Pressure from PLACE / position / sophistication (mature gravitas, the room-they're-in matters) → **Space-stressed**
- Pressure from FEELING (emotional yielding visible, flow of sentiment showing through) → **Flow-stressed**

**Hard rules:**
- Stable: choose Time OR Flow (Space-stressed Stable does not exist)
- Adream: choose Time OR Space
- Near: choose Space OR Flow

### Q1.4 — Drive lock

**Ask:** "Does this brand's voice NEED urgency theatre to work? Do customers expect 'act now' and 'limited time' from this voice? Or does the voice instead carry a sense of timelessness — patient craft, this-has-been-building-for-years, future-pulled but not time-pressed?"

- Needs urgency → **Passion-drive** is on-spec (likely Time-stressed)
- Timeless craft, no urgency → **Spell-drive** (Time-stress is off-spec; choose Flow or Space)

### Q1.5 — Aspect (only after baseline + stress locked)

**Show the operator the 2-4 aspects available for the chosen baseline:**

- Stable: Enclosing (Intending — sensuous, enfolding) or Penetrating (Attending — thinking-focused)
- Adream: Enclosing (Intending — sensuous) or Radiating (Adapting — feeling-radiating)
- Near: Enclosing (Intending — earthy, weighty) or Circumscribing (Deciding — conventional/imitative)

**Ask:** "Which feels right — thinking-focused / sensuous-enfolding / feeling-radiating / conventional-thought-as-cover?"

### Output of Move 1

A locked placement: e.g., `Stable + Flow-stressed + Penetrating, Drive: Spell-Vision (Diagram D)` (Infinex).

## Move 2 — Tempi rotation + cadence

### Q2.1 — Walk the 12 tempi

Show the operator the full 12 tempi available for their baseline (4 internal Stable variations + 4 of each outer projection, OR 4 Adream variations + 4 of each outer, etc.). For each, show:

- The Mirodan label
- The motor pair (e.g., Pressing → Punching)
- The "feel" sentence
- 1-2 example posts from the few-shot library

Use the same product fact (release card) across all 12 to let the operator A/B feel.

### Q2.2 — Main rotation pick

**Ask:** "Which 3-5 tempi feel like home for this voice? Which others belong in the toolkit but should fire rarely?"

Typical: 3-5 main tempi + 7-9 beat-only. Don't accept "all 12 as main" — voice without rotation is no voice.

### Q2.3 — Cadence approximation

**Ask, for each main tempo:** "When the brand posts 10 times, how many of those posts open / live in this tempo?"

Capture approximate percentages summing to 1.0 across main tempi.

### Output of Move 2

A `main_tempi: TempoName[]` + `beat_only_tempi: TempoName[]` + `cadence: Partial<Record<TempoName, number>>`.

## Move 3 — Beat sequences + few-shot + off-spec rules

### Q3.1 — Beat sequence per release-card kind

Walk the operator through their release-card kinds (launch, data-update, partner-announcement, post-mortem, status-report, etc.). For each, draft a canonical beat sequence and ask: "for a typical [launch], does the post want to arc Sombre → Commanding → Practical → Irradiant? Or something else?"

Capture as `defaultBeatsForKind(kind: string) → TempoName[]`.

### Q3.2 — Few-shot library

**Ask:** "Give me 3 real examples of voice you wish the brand sounded like — yours or other accounts. Doesn't have to be perfect; we'll iterate."

For each, identify which tempo it best exemplifies and add to that tempo's `example_lines[]`. The generator uses these as priming.

### Q3.3 — Off-spec regex iteration

Show the operator the default off-spec regexes for their Drive lock (e.g., for Spell-Vision: time-pressure / FOMO / hype-theatre lists).

**Ask:** "Anything missing? Anything you want to add specifically because past comms used it?"

Capture as `off_spec_regexes: { name, re, reason }[]`.

### Output of Move 3

A complete `CharacterSpec` ready to write into `src/voice/<brand>.ts`.

## After the interview — verification

1. Generate 3 sample posts using the spec (run the stub generator).
2. Show them to the operator alongside the operator's own examples.
3. If 2 of 3 generated posts read as "the brand" without intervention, ship the spec.
4. If not, ask: "what about [specific post] is off?" — and iterate the off-spec regex, the few-shots, or the cadence based on the answer.

The spec is a living artifact, not a one-shot output. The first 30 days after deployment will surface 5-10 regexes / few-shot updates the interview missed.

## Time budget

- Move 1: 20-30 minutes
- Move 2: 30-60 minutes (the 12-tempo A/B is the bulk)
- Move 3: 30-45 minutes
- Verification: 15 minutes

Total: ~2 hours for a complete locked spec, vs ~10 sessions across weeks without this skill.
