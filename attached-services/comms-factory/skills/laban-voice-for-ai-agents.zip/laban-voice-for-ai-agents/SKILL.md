---
name: laban-voice-for-ai-agents
description: Use this skill when designing, validating, or generating brand-voice content for an AI agent or brand. It encodes Veronica Mirodan's 1997 PhD synthesis of Laban Movement Analysis into a practical 3-move workflow that takes a brand from "we want a voice" to a locked, mechanically-validatable voice spec with a working generator/validator loop. Use when you see the word "Laban", "Mirodan", "voice spec", "tempo", "tone of voice", "Working Action", or when an operator says they want their brand's content to sound a specific way and they need a structured way to get there.
metadata:
  tags: laban, mirodan, voice, brand, character, ai-agent, slop-prevention
---

# Laban-Mirodan voice for AI agents

This skill turns "we want our brand to sound like X" into a mechanically-validatable voice spec that an AI agent can actually generate against. It's the methodology that produced the Infinex voice (Stable + Flow-stressed + Penetrating, Spell-Vision drive, 5 main tempi in beat-sequence architecture) and that grounds Nigel's voice subsystem.

## ⚠ STUPID MISTAKES — never make these

These are the failure modes that wasted hours of operator time. The framework is mechanical; these errors come from skipping the mechanics and reasoning from feel. **Read this before doing anything else.**

### The available-stresses rule

A baseline character's two available stresses are the two Motion Factors **NOT in its Inner pair**. That's it. Memorize this:

```
Stable inner = Weight + Space → available stresses: TIME or FLOW (never Space, never Weight)
Adream inner = Weight + Flow  → available stresses: TIME or SPACE (never Flow, never Weight)
Near   inner = Weight + Time  → available stresses: SPACE or FLOW (never Time, never Weight)
```

**Combinations that DO NOT EXIST and will get you corrected by anyone fluent:**
- ❌ Space-stressed Stable (Stable's inner already has Space)
- ❌ Flow-stressed Adream (Adream's inner already has Flow)
- ❌ Time-stressed Near (Near's inner already has Time)
- ❌ Weight-stressed anything (Weight is in every baseline's inner pair)

If you find yourself about to type one of those, stop and re-check the baseline's inner pair.

### Mobile, Remote, Awake are NEVER baselines

They are outer Action Attitudes ONLY. They fire as projections of Stable, Adream, or Near under stress. A character spec with `inner_attitude: "remote"` is invalid. Mirodan §3.4-3.6 is explicit: "There are no genuinely Mobile characters" (and the same for Remote and Awake).

If an operator says "the brand feels Remote / dreamy / detached," they mean an Adream or Stable baseline that projects Remote as outer when Flow-stress fires. Pin the baseline first.

### Laban ≠ Mirodan

Laban Movement Analysis is the underlying framework (4 motion factors, 8 effort actions, etc.). Mirodan's 1997 PhD synthesizes Laban + Yat Malmgren + Carpenter into a working character vocabulary (~70 specialised terms) for theatre. **Mirodan is denser, sharper, and overrides several simpler Laban readings** (top-12 overrides in `references/mirodan-master.md` §1).

Treating them interchangeably will cause you to miss key overrides — especially the three-baseline rule, the Adream split (§4.5), and the Fusion mechanic on Flow only (§1).

### Cadence is per-post; beats are per-paragraph

A post is a beat sequence (~3-4 paragraphs, each in its declared tempo). Cadence is the meta-statistic — what percentage of posts open in which tempo over time. **They are not the same axis.** Operators sometimes give cadence percentages and you assume single-tempo posts. Always check whether posts are multi-beat in this brand's voice.

### Drive determines off-spec language, not vibes

If the operator says "we want timeless, not urgent" → Spell drive locked → Passion-vocabulary is off-spec. The validator regex enforces this mechanically. Don't paper over with "but this one ad needs urgency" — either the spec was wrong (rerun Move 1) or the operator wants two characters (don't).

---

## When to use this skill

- You're starting a brand voice from scratch and want it to be more than vibes
- An operator describes their voice in terms an AI agent can't act on ("warm but not soft, confident but not arrogant, kind of like Karpathy but for crypto")
- You're building a generator/validator loop for branded content and need the validator to have actual rules
- You see the word "Laban", "Mirodan", "tempo", "Working Action", "Inner Attitude", "Stable", "Adream", "Near"
- You're handed an existing voice spec and need to audit whether it's coherent under Mirodan
- You're trying to figure out why some posts from a brand land and others don't — Mirodan's status-grammar and Drive-axis lenses often diagnose this

## What this skill produces

A complete `CharacterSpec` object containing:

1. **Inner Attitude** (Stable, Adream, or Near — only these 3 can baseline)
2. **Stress** (Time, Space, or Flow — restricted to the two stresses available to the chosen baseline)
3. **Aspect** (Enclosing, Penetrating, Circumscribing, or Radiating)
4. **Drive axis** (combination of Doing, Spell, Passion, Vision — locks which language families are off-spec)
5. **Main tempi rotation** (typically 3-5 tempi in regular use; the rest available as rare beats)
6. **Off-spec regex rules** (vocabulary that violates the locked Drive)
7. **Cadence distribution** (approximate % per main tempo)
8. **Beat-sequence templates** (default beat order per release-card kind)
9. **Few-shot example library** (real sample posts per tempo, used as generator priming)

Plus a working generator + validator pair that consumes this spec.

## Fast path — 3 questions to a draft spec

For operators who don't want the long workflow, this is the minimum interview. Answer these three, and the spec writes itself (with one Aspect follow-up):

### Question 1 — WHO is the character?

Give a concrete image, not adjectives. **"Old curmudgeon at the end of the bar."** **"The shipwright building the boat to the new continent."** **"A psychohistorian who plots 1000 years ahead."** **"The taxman."** **"Your sober friend at 2am."**

If the operator gives adjectives ("warm, confident, but not arrogant"), push back: *"what KIND of person is warm-confident-not-arrogant? Give me the room they're in."*

### Question 2 — What PRESSES them?

- TIME — deadlines, must-act-now, urgency-as-virtue → **Time-stressed**
- SPACE — mature gravitas, room-they're-in matters, position/sophistication → **Space-stressed**
- FLOW — emotional yielding visible, sentiment showing through cracks → **Flow-stressed**

### Question 3 — Do they NEED urgency theatre to work?

- YES — customers expect "act now" / "limited time" / FOMO → **Passion drive on-spec**
- NO — timeless craft, patient build, this-has-been-coming-for-years → **Spell drive (Passion off-spec)**

### Decision tree to placement

```
Q1 reveals the basic shape:
  - Ships things, decisions taken → Stable baseline
  - Vision-pulled, torn between feeling and grounding → Adream baseline
  - Down-to-earth, sensory, common sense → Near baseline

Q2 + the available-stresses rule narrows it:
  - Stable + Time-stressed → outer projects as Near + Awake (brutal "rock-like Stable")
  - Stable + Flow-stressed → outer projects as Adream + Remote (softer, yielding)
  - Adream + Time-stressed → outer fragments to Near + Mobile (Adream split)
  - Adream + Space-stressed → outer consolidates to Stable + Remote (aristocratic aloofness)
  - Near + Space-stressed → outer projects as Stable + Awake (down-to-earth becomes intellectual)
  - Near + Flow-stressed → outer projects as Adream + Mobile (Big Daddy energy)

Q3 locks the Drive:
  - Time-stress always activates Passion
  - Flow-stress on Stable → Spell + Vision (Diagram D) — no Passion
  - Space-stress on Adream Radiating → Spell + Passion + Vision (Diagram B)
  - Adream + Enclosing variants → Spell + Doing
  - Near is always Doing + Passion (Spell-only Near doesn't exist)

If Q3 = "no urgency" but Q1 said "Near baseline" → contradiction. Surface to operator:
  "Near is structurally Doing+Passion-driven. If you don't want Passion, the
  character isn't Near. Re-pick Q1."
```

### Follow-up: Aspect (1 more question after the 3)

Once baseline + stress are locked, ask the **Aspect question** with the 2 valid options for that baseline:

- **Stable**: Enclosing (sensuous, enfolding — Hawthorne) or Penetrating (thinking-focused — the Duke, Werle)
- **Adream**: Enclosing (sensuous — Claudius, Othello) or Radiating (feeling — Hamlet, Hedda)
- **Near**: Enclosing (earthy, weighty — Big Daddy) or Circumscribing (conventional/imitative — Tesman, soldiers)

**Total: 4 questions to a complete placement.** Then move to cadence (Move 2) and beat sequences (Move 3) — but the placement is the hard part; once it's locked, the rest is mechanical.

## The full 3-move workflow

Detailed version of the above. Use when the operator wants to A/B feel before locking — typically for the first brand they run through the skill.

### Move 1 — Inner Attitude + Stress + Drive (the placement)

Ask the operator these questions in order. Each answer constrains the next.

1. **"Who is the character behind this brand when a reader encounters them?"** (Best friend? Accountant? Taxman? Mentor? Trickster? Old curmudgeon at the bar? The architect of a bridge?) — surface a concrete image, not a list of traits.
2. **"Does this character SHIP things, or are they VISION-pulled toward a future their grounding doesn't quite reach?"** — Shippers anchor to Stable (intelligent ruler, decisions taken). Vision-pulled-but-torn anchor to Adream (the lover, doubly unaware, vision exceeds grounding). Down-to-earth-sensory anchor to Near (a spade's a spade, common sense).
3. **"Is the brand TIME-pressed (urgency theatre is on-spec), SPACE-pressed (mature gravitas), or FLOW-pressed (emotional yielding visible)?"** — restrict to the two stresses available for the chosen baseline (see `references/mirodan-master.md` §4.1).
4. **"Does the voice need urgency theatre to work?"** (yes → Passion-drive is on-spec → likely a Time-stressed character; no → Spell-driven, future-tense and craft-patience are native)

Map the answers to placement using the deterministic table in `references/mirodan-master.md` §4.1. If the operator's answers contradict each other (e.g., "vision-pulled-torn" + "no urgency" — Adream rules out the no-Passion option for Time-stress, and Space-stressed Adream mixes Spell with Passion), surface the contradiction and ask which they want to keep.

**Hard rules (never violate):**
- Mobile, Remote, Awake can NEVER be the baseline — they are Action Attitudes only (outer projections).
- Space-stressed Stable does NOT exist (Stable's Inner = Weight+Space, so Space cannot be the stress).
- The three opposite-pairs are mutually exclusive: Stable↔Mobile, Near↔Remote, Awake↔Adream.

### Move 2 — Aspect + tempi rotation + cadence

Once placement is locked, the available tempi are determined.

5. **Aspect** — show the operator the 2-4 aspects available for the chosen baseline (Stable: Enclosing or Penetrating; Adream: Enclosing or Radiating; Near: Enclosing or Circumscribing). Ask which orientation fits — thinking-focused (Penetrating), sensuous-enfolding (Enclosing), feeling-radiating (Radiating), thought-as-cover (Circumscribing).

6. **Cadence interview.** Show the operator the 12 tempi available (4 baseline-internal variations + 4 of each outer projection — see `references/working-actions.md` for the full table). Walk through sample posts in each tempo (use the same product fact across all 12 — A/B comparison). Operator picks 3-5 as the main rotation and assigns approximate percentages. The rest stay in the toolkit as rare beats.

The cadence is approximate, not enforced — the spec captures intent. Concrete example from the Infinex spec: `Irradiant 45% / Commanding 22% / Sombre 18% / Sociable 10% / Practical 5%`.

### Move 3 — Beat-sequence templates + few-shot library + off-spec regexes

7. **Beat-sequence per release-card kind.** Posts arc through tempi as beat sequences, not single-tempo monoliths. For each release-card kind (launch, data-update, partner-announcement, post-mortem), draft the canonical beat sequence. Example for a major launch: `Sombre (Pressing prep) → Commanding (Punching release) → Practical (Wringing/Slashing justify) → Irradiant (Floating/Flicking lift)`.

8. **Few-shot library.** Take 3-5 sample posts per main tempo (real, ideally drawn from existing voice or from accounts the operator admires). These become the generator's prompt examples.

9. **Off-spec regex rules.** Based on the Drive lock, identify vocabulary families that activate off-spec drives. Time-pressure markers (`act now`, `hurry`, `last chance`) activate Passion — off-spec for any Spell-only or Vision-only character. Hype theatre (`buckle up`, `wagmi`, `let's go`) activates Passion. Build a regex per family.

Output: a `CharacterSpec` in TypeScript matching `src/voice/types.ts` (see Infinex's at `src/voice/infinex.ts`).

## Generator + validator architecture

The voice spec feeds directly into the existing scaffold at `comms-factory/src/`:

```
release card  →  generator  →  validator  →  orchestrator  →  ship gate
                     ↑              ↑
            voice spec       voice spec
            + beats[]        + beats[]
```

### Generator (`src/generator.ts`)
- Takes `(ReleaseCard, BeatSequence, CharacterSpec)`
- Builds a system prompt containing:
  - Placement (Inner + Stress + Aspect + Drive)
  - Main tempi reference (motor pairs + opening shapes + vocab + few-shots)
  - Preparation hierarchy reminder (Quick action needs Sustained prep)
  - Hard rules + off-spec drive language
- Builds a user prompt with the release card + the declared beat sequence
- Returns N candidates, each a multi-paragraph post (one paragraph per beat)
- Falls back to a deterministic stub mode when `ANTHROPIC_API_KEY` is unset (composes sample post from the few-shot library)

### Validator (`src/validator.ts`)

**Layer 1 — regex-grade slop/allergen rules (brand-agnostic):**
- `rejectCliches` — game-changer / unlock / paradigm / seamless / empower / next-gen / leverage
- `rejectListicleVoice` — N reasons / why X matters / top N / only X you'll ever need
- `rejectAntagonism` — competitor names paired with negative descriptors
- `rejectAIslop` — vague nouns + em-dash density (> 2 per 280 chars)
- `rejectKainBaggage` / `rejectClaimedPalettes` — brand-specific allergens
- `rejectOffSpecDrive` — Drive-lock regex (time-pressure / hype-theatre for Spell-Vision)

**Layer 2 — beat-sequence audit (Mirodan-grounded):**
- `auditPrepHierarchy(beats)` — checks that every Quick action has its Sustained prep in an earlier beat
- `auditBeats(text, beats)` — splits post into paragraphs, classifies each against declared tempo, reports mismatches

**TODO (Nigel Track-5b mechanic):** intent-consistency-vs-blind-classify. Currently `auditBeats` uses vocab-anchor regex; the production version should call Claude Sonnet to blind-classify each beat's tempo and confidence, then compare to the declared tempo. The pattern is in `references/nigel-pattern.md`.

## Example: the Infinex spec at full fidelity

`examples/infinex-voice-spec.md` shows the locked Infinex voice as a complete worked example. Reading it end-to-end takes ~10 minutes and produces an agent that can generate posts in voice.

## Related skills

This skill is for **creating a voice from scratch**. Once a voice is locked and the generator/validator loop is running, downstream extensions use:

- **`nigel-voice-extend`** — adding a new post type to an existing voice subsystem (e.g., epoch_open, drawdown_post, anniversary_post). Captures the seven file shapes a new post type requires + the specific gotchas that bit on Nigel's Track 9 build. Different concern: this skill creates the voice; `nigel-voice-extend` extends it with new card types after it's running.

If you're being asked to "add a new post type to Infinex" or similar, you want `nigel-voice-extend`, not this skill. If you're being asked to "build a voice for X" or "we need a brand voice", you want this skill (then `nigel-voice-extend` for each new post type after).

## Reference materials

- `references/mirodan-master.md` — the full Mirodan synthesis (462 lines, includes top-12 overrides of simpler Laban readings). The single most important file in this skill.
- `references/working-actions.md` — the 8 Working Actions table + preparation hierarchy
- `references/drive-mapping.md` — Drive sub-diagrams; how Inner + Stress + Aspect determine which Drives are active
- `references/nigel-pattern.md` — the generator/validator/orchestrator pattern from Nigel (the prior voice subsystem this skill generalizes)

Mirodan's original PhD is at `Mirodan-PhD-1997-Vol2.pdf` (50MB, not included in this skill — locate it in the operator's Downloads or via library.london.ac.uk).

## Templates

- `templates/interview-questions.md` — the question scripts for Moves 1-3
- `templates/voice-spec-template.md` — fillable TypeScript skeleton
- `templates/beat-sequence-templates.md` — canonical beat orders per release-card kind

## Examples

- `examples/infinex-voice-spec.md` — Infinex: Stable + Flow + Penetrating, Spell-Vision, 5-tempo rotation. Includes all 36 sample posts (3 facts × 12 tempi).
- `examples/nigel-summary.md` — Nigel for reference: Flow-stressed Stable, Bound, Light + Direct, three registers (Self-Contained / Diffused / Egocentric).

## Hard rules to never break

```
1. Mobile, Awake, Remote are NEVER baselines. CharacterSpec.inner_attitude
   must be one of: Stable, Adream, Near.

2. Available stresses are determined by the baseline:
   - Stable: time | flow  (NOT space)
   - Adream: time | space (NOT flow)
   - Near:   space | flow (NOT time)

3. The three opposite-pairs are absolute:
   Stable ↔ Mobile, Near ↔ Remote, Awake ↔ Adream.

4. Preparation hierarchy: every Quick action requires its Sustained partner
   as prep, or it degrades.

5. Drive determines off-spec language:
   - Time-stress activates Passion drive
   - Flow-stress on Stable activates Spell (no Passion)
   - Space-stress on Adream mixes Spell with Passion
   - Off-spec language is the part of Drive language the character does NOT carry.

6. Inner Attitudes use 2 Motion Factors → Shadow Moves (subliminal).
   Action Attitudes use 3 Motion Factors → visible Working Actions.
   The Stress is the bridge — the third axis.
```

## Operator success criteria

This skill has succeeded for an operator when:

1. They can answer "who is X when a reader encounters them?" with a concrete image
2. They have a locked `CharacterSpec` (placement + cadence + off-spec rules)
3. The generator produces posts in their voice on first call (with sensible beat sequences)
4. The validator rejects slop without manual rule-writing per failure
5. They can extend the spec (add tempi, refine off-spec regexes) without needing this skill again

If any of these fail, the workflow surfaced a contradiction that needs the operator's judgment — surface it, don't paper over it.
